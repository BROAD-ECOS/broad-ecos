<?php

return [
  'FS_REPO' => 'Local',
  'FS_LOCAL_ENDPOINT' => __DIR__.'/uploads',
  'LOG_FILESTORE' => __DIR__.'/app/storage/logs/laravel.log',
];