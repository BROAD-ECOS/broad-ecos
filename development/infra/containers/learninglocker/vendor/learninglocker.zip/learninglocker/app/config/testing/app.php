<?php

return array(
  'providers' => append_config(array(
  	'Jenssegers\Mongodb\Auth\ReminderServiceProvider'
   ))
);