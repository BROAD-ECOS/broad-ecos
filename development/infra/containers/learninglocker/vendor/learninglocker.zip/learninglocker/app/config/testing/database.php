<?php

return array(
  'connections' => array(
    'mongodb' => array(
      'driver'   => 'mongodb',
      'host'     => 'localhost',
      'port'     => 27017,
      'username' => '',
      'password' => '',
      'database' => 'lltest'
    )
  )
);
