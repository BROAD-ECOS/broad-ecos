<?php

return [
  'errors' => [
    'not_found' => 'Die Klasse :class mit der id `:id` konnte nicht gefunden werden.'
  ],
  'info' => [
    'trace' => 'Um einen Trace zu erhalten muss die Einstellung `debug` auf `true` gesetzt sein.'
  ]
];