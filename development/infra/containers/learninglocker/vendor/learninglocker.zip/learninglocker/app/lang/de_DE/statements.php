<?php

/*
|----------------------------------------------------------------------------
| Translations for statements
|----------------------------------------------------------------------------
*/

return array(
    'statements' => 'Statements',
    'generator' => 'Generator',
    'filter' => 'Filter',
    'explorer' => 'Explorer',
    'reporting' => 'Reporting',
    'exporting' => 'Exporting',
    'analytics' => 'Analytik',
    'added' => 'Das Statement wurde hinzugefügt.'
);