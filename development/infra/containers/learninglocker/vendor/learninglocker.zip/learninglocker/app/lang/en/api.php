<?php

return [
  'errors' => [
    'not_found' => 'Could not find :class with id `:id`'
  ],
  'info' => [
    'trace' => '`debug` must be `true` in the App\'s config to get a trace.'
  ]
];