<?php

/*
|----------------------------------------------------------------------------
| Translations for statements
|----------------------------------------------------------------------------
*/

return array(
    'statements' => 'Statements',
    'generator'  => 'Generator',
    'filter'	 => 'filter',
    'explorer'   => 'Explorer',
    'reporting'  => 'Reporting',
    'exporting'  => 'Exporting',
    'analytics'  => 'Analytics',
    'added'		 => 'Your statement has been added.'
);