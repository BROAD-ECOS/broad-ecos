<?php

/*
|----------------------------------------------------------------------------
| Translations for statements
|----------------------------------------------------------------------------
*/

return array(
    'statements' => 'Sentencias',
    'generator'  => 'Generador',
    'filter'	 => 'filtro',
    'explorer'   => 'Explorador',
    'reporting'  => 'Informes',
    'analytics'  => 'Estadísticas',
    'added'		 => 'Su sentencia ha sido añadida'
);