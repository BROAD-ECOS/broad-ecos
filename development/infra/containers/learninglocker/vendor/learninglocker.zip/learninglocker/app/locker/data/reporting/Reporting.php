<?php namespace app\locker\data;

class Reporting extends BaseData {

}