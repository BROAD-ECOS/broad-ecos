<?php namespace Locker\Graphing;

interface GraphingInterface {

  public function morrisLineGraph( $data );

}