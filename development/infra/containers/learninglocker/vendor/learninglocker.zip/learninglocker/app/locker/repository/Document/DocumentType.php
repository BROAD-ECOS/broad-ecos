<?php namespace Locker\Repository\Document;

class DocumentType{
  const STATE     = 'state';
  const ACTIVITY  = 'activityProfile';
  const AGENT     = 'agentProfile';
}