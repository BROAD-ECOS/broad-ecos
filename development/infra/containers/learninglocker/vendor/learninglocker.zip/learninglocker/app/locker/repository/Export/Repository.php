<?php namespace Locker\Repository\Export;

interface Repository extends \Locker\Repository\Base\Repository {}