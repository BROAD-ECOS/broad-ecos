<?php namespace Locker\Repository\File;

interface Repository extends \Locker\Repository\Base\Repository {
}
