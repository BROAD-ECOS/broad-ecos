<?php namespace Tests\Repos\Statement;

use \Tests\StatementsTestCase as StatementsTestCase;

abstract class EloquentTest extends StatementsTestCase {

  public function setup() {
    parent::setup();
  }

  public function tearDown() {
    parent::tearDown();
  }
}
