@if( Auth::check() )
  
  @include('layouts.sidebars.sidebar_footer')

@endif