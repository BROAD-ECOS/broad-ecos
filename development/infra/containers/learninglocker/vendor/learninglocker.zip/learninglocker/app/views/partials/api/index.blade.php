@extends('default')

@section('contents')

  <div class="page-header">
    <h1>LRS API</h1>
  </div>

  <div class="row">
    <div class="col-xs-12 col-sm-12 col-lg-12">
      <p>This will be about this lrs's API.</p>
    </div>
  </div>

@stop