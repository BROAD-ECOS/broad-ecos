{{ HTML::script('assets/js/libs/morrisjs/raphael.min.js') }}
{{ HTML::script('assets/js/libs/morrisjs/morris.min.js') }}