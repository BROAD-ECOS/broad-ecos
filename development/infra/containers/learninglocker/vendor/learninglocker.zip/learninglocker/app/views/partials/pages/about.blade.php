@extends('layouts.master')

@section('sidebar')
  @include('layouts.sidebars.blank')
@stop

@section('content')

  <div class="page-header">
    <h1>About</h1>
  </div>

  <p>All about Learning Locker.</p>

@stop