@extends('layouts.master')

@section('sidebar')
  @include('layouts.sidebars.blank')
@stop

@section('content')

  <div class="page-header">
    <h1>Help</h1>
  </div>

  <p>This will be help documents.</p>

@stop