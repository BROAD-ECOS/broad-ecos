@extends('layouts.master')

@section('sidebar')
  @include('layouts.sidebars.blank')
@stop

@section('content')

<div class="page-header">
  <h1>Terms of service</h1>
</div>

@stop