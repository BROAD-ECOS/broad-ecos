<header class="page-header">
  <h2>{{ $page }}</h2>
</header>