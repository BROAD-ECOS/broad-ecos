<div class="row">
  <div class="col-xs-6 col-sm-2">
    <div class="explore-option active">
      <span class="blue-icon"><i class="icon icon-comments"></i></span>
      Comments
    </div>
  </div>
  <div class="col-xs-6 col-sm-2">
    <div class="explore-option disable">
      <span class="blue-icon"><i class="icon icon-bar-chart"></i></span>
      Results
    </div>
  </div>
  <div class="col-xs-6 col-sm-2">
    <div class="explore-option disable">
      <span class="blue-icon"><i class="icon icon-shield"></i></span>
      Badges
    </div>
  </div>
  <div class="col-xs-6 col-sm-2">
    <div class="explore-option disable">
      <span class="blue-icon"><i class="icon icon-group"></i></span>
      Learners
    </div>
  </div>
  <div class="col-xs-6 col-sm-2">
    <div class="explore-option disable">
      <span class="blue-icon"><i class="icon icon-book"></i></span>
      Courses
    </div>
  </div>
  <div class="col-xs-6 col-sm-2">
    <div class="explore-option disable">
      <span class="blue-icon"><i class="icon icon-puzzle-piece"></i></span>
      Activities
    </div>
  </div>
</div>
<!-- 
<div class="selector">
  <div class="row">
    <div class="col-xs-12 col-sm-3">
      Course:
      <select class="form-control">
        <option>All</option>
        <option>Course one</option>
        <option>Course one</option>
      </select>
    </div>
    <div class="col-xs-12 col-sm-3">
      Activity:
      <select class="form-control">
        <option>All</option>
        <option>Object two</option>
        <option>Object three</option>
      </select>
    </div>
    <div class="col-xs-12 col-sm-2">
      Platform:
      <select class="form-control">
        <option>All</option>
        <option>One</option>
        <option>Two</option>
      </select>
    </div>
    <div class="col-xs-12 col-sm-2">
      Learner:
      <select class="form-control">
        <option>All</option>
        <option>Learner two</option>
        <option>Learner three</option>
      </select>
    </div>
    <div class="col-xs-12 col-sm-2">
      <p></p>
      <button class="btn btn-primary btn-block">Submit</button>
    </div>
  </div>
</div>
-->
<hr>