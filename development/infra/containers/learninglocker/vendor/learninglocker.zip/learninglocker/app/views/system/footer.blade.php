@section('footer')

<!-- required scripts -->
@section('scripts')
  {{ HTML::script('assets/js/libs/jquery/jquery.1.10.2.js') }}
  {{ HTML::script('assets/js/libs/bootstrap/bootstrap.min.js') }}
  {{ HTML::script('assets/js/respond.min.js') }}
  {{ HTML::script('assets/js/placeholder.js') }}
@show

@show
</body>
</html>