# Contributors
> Learning Locker is a community effort sponsored by [HT2](http://ht2.co.uk), this page lists those who have been involved in its development.

## Core Contributors
- [Dave Tosh](http://twitter.com/davetosh)
- [James Mullaney](mailto:james@ht2.co.uk)
- [Ryan Smith](https://github.com/ryansmith94)

## Community Contributors
- [James Richards](https://github.com/pondermatic)
- [Andy Truong](https://github.com/andytruong)
- [Andrew Downes](https://github.com/garemoko)
- [François Moreau](https://github.com/lampyridae)
- [Anna Smith](https://github.com/annasmith)
- [Kazutaka Kamiya](https://github.com/kzkamiya)
- [Pete Thorne](https://github.com/ee0pdt)
- [Pan Luo](https://github.com/xcompass)
- [Charyorde](https://github.com/charyorde)
