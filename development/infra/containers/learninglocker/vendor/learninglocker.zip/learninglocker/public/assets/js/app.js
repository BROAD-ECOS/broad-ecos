$(document).ready(function() {

  $('span.verify').tooltip();

  //placeholder for IE
  $('input, textarea').placeholder();

});