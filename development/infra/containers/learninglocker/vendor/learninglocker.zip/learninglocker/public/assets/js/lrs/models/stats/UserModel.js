define([
  'underscore',
  'backbone',
  'app'
], function(_, Backbone, App) {
  
  var UserModel = Backbone.Model.extend({});

  return UserModel;

});