define(['backbone.wreqr'], function(Wreqr){
  "use strict";
  return new Wreqr.EventAggregator();
});