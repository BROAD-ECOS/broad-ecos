// This just runs gulpfile.coffee.
require('coffee-script/register')
require('./gulpfile.coffee')